import sys
from .otel_core_config import OtelCoreLoggingConfig
from ..hooks.celery_hooks import attach_celery_hooks
from ..filters.celery import TaskContextFilter
from ..celery_role import CeleryRole
from ..formatters.celery_formatter import CeleryOTELFormatter

class CeleryLoggingConfig(OtelCoreLoggingConfig):
    def __init__(self, celery_app, role: CeleryRole = CeleryRole.WORKER, *args, **kwargs):
        # Set the specific formatter class before calling the parent constructor.
        # This ensures the correct formatter is passed to BaseLoggingConfig.
        kwargs["formatter_class"] = CeleryOTELFormatter
        super().__init__(*args, **kwargs)

        self.celery_app = celery_app
        self.role = role
        self.filters.append(TaskContextFilter())

    def setup(self):

        super().setup()

        # important to attach the hooks before starting celery auto instrumentation
        attach_celery_hooks(celery_app=self.celery_app)

        from opentelemetry.instrumentation.celery import CeleryInstrumentor
        # If the role is 'producer', instrument immediately. This is for applications
        # that send tasks (e.g., a Flask app). This ensures trace context is
        # injected into the task messages.
        if self.role == CeleryRole.PRODUCER:
            CeleryInstrumentor().instrument()

        from celery.signals import worker_process_init
        # Always connect to the worker_process_init signal. This is the standard
        # OpenTelemetry practice for Celery. It ensures that instrumentation
        # runs exactly once inside each forked worker process, which is where
        # tasks are executed. This is a no-op in producer processes.
        @worker_process_init.connect(weak=False)
        def init_celery_instrumentor_in_worker(*args, **kwargs):
            # This will only run inside a forked worker process.
            CeleryInstrumentor().instrument()
