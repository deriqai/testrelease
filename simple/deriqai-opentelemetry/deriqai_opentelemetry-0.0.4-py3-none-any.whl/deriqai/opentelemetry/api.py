import logging
from .app_type import AppType
from .logger_factory import LoggingFactory

def configure(
    app=None,
    app_type: AppType = AppType.OTEL_CORE,
    resource: dict | None = None,
    level: int = logging.INFO,
    **kwargs
) -> None:
    """
    Configure OpenTelemetry-compliant logging.

    Args:
        app: Optional application instance (e.g., Flask app, Celery app).
        app_type (AppType): The application type (FLASK, CELERY, OTEL_CORE, ...).
        resource (dict): OpenTelemetry resource attributes
                         (e.g., {"service.name": "my-service"}).
        level (int): Logging level (default=logging.INFO).

    Example:
        >>> import otel_logging
        >>> otel_logging.configure(
        ...     app_type=AppType.OTEL_CORE,
        ...     resource={"service.name": "my-app"},
        ...     level=logging.DEBUG
        ... )
    """
    LoggingFactory.create(
        app=app,
        app_type=app_type,
        resource=resource,
        level=level,
        **kwargs
    )
