import logging
from contextvars import ContextVar
from typing import Any, Dict, Optional
from opentelemetry.trace import get_current_span

# Define context variables that can be set by framework-specific code
# (e.g., a Flask middleware or a Celery task signal).
request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)
user_var: ContextVar[Optional[Dict[str, Any]]] = ContextVar("user", default=None)


class RequestIDContextFilter(logging.Filter):
    """Injects a request_id from a context variable into the log record."""
    def filter(self, record):
        # Use the value from the context variable if 'request_id' is not already on the record.
        if not hasattr(record, "request_id"):
            record.request_id = request_id_var.get()
        return True

class UserContextFilter(logging.Filter):
    """Injects user information from a context variable into the log record."""
    def filter(self, record):
        # Use the value from the context variable if 'user' is not already on the record.
        if not hasattr(record, "user"):
            record.user = user_var.get()
        return True

class TraceContextFilter(logging.Filter):
    """Attach OTEL trace_id, span_id, and span_name to log records."""
    def filter(self, record):
        span = get_current_span()
        ctx = span.get_span_context() if span else None
        if ctx and ctx.trace_id != 0:
            record.trace_id = format(ctx.trace_id, '032x')
            record.span_id = format(ctx.span_id, '016x')
            record.span_name = span.name
        else:
            record.trace_id = None
            record.span_id = None
            record.span_name = None
        return True
