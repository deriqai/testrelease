import importlib.metadata
from .app_configs.flask_config import FlaskLoggingConfig
from .app_configs.celery_config import CeleryLoggingConfig
from .app_configs.otel_core_config import OtelCoreLoggingConfig
from .filters.otel_core import RequestIDContextFilter, UserContextFilter, TraceContextFilter
from .app_type import AppType
from .formatters.otel_core_formatter import OTELFormatter


_PACKAGE_NAME = __name__.split('.')[0]
_INSTRUMENTATION_NAME = ".".join(__name__.split('.')[:2])

try:
    # This reads the version from the installed package's metadata.
    # The package name is derived from the module's __name__.
    __version__ = importlib.metadata.version(_PACKAGE_NAME)
except importlib.metadata.PackageNotFoundError:
    # Fallback for when the package is not installed (e.g., running in development).
    __version__ = "0.0.0-dev"

class LoggingFactory:
    DEFAULT_FILTERS = [
        RequestIDContextFilter(),
        UserContextFilter(),
        TraceContextFilter(),
    ]

    @staticmethod
    def create(app=None, app_type: AppType = AppType.OTEL_CORE, resource=None,
               filters=None, handlers=None, level=None, **kwargs):
        all_filters = LoggingFactory.DEFAULT_FILTERS.copy()
        if filters:
            all_filters.extend(filters)

        instrumentation_scope={
            "name": _INSTRUMENTATION_NAME,
            "version": __version__
        }

        config_class = {
            AppType.FLASK: FlaskLoggingConfig,
            AppType.CELERY: CeleryLoggingConfig,
            AppType.OTEL_CORE: OtelCoreLoggingConfig
        }.get(app_type, OtelCoreLoggingConfig)

        config_kwargs = {
            "resource": resource,
            "instrumentation_scope": instrumentation_scope,
            "filters": all_filters,
            "handlers": handlers,
            "level": level,
            "formatter_class": OTELFormatter,
            **kwargs
        }

        if app_type in [AppType.FLASK, AppType.CELERY]:
            if app is None:
                raise ValueError(f"The 'app' argument is required for app_type '{app_type.name}'")
            config = config_class(app, **config_kwargs)
        else:
            config = config_class(**config_kwargs)

        config.setup()
        return config
