import logging
from .otel_core import user_var

class FlaskRequestContextFilter(logging.Filter):
    def filter(self, record):
        # deferred loading
        from flask import has_request_context, request

        if has_request_context():
            # Capture more request attributes and align with OpenTelemetry semantic conventions.
            host_parts = request.host.split(':', 1)
            host = host_parts[0]
            port = None
            if len(host_parts) == 2:
                try:
                    port = int(host_parts[1])
                except ValueError:
                    pass  # Should not happen with valid Host headers

            target = request.path
            query = request.query_string.decode("utf-8")
            if query:
                target = f"{target}?{query}"

            record.flask_request = {
                "http.method": request.method,
                "http.scheme": request.scheme,
                "http.host": host,
                "http.port": port or (443 if request.scheme == 'https' else 80),
                "http.target": target,
                "client.address": request.remote_addr,
                "http.user_agent": request.user_agent.string,
            }
            # http.route is the parameterized URL path.
            # e.g., /users/<int:user_id>
            if request.url_rule:
                record.flask_request["http.route"] = request.url_rule.rule
            
            user_info = user_var.get()
            if user_info:
                # Add end-user attributes, following OpenTelemetry semantic conventions.
                for key, value in user_info.items():
                    record.flask_request[f"enduser.{key}"] = value

        else:
            record.flask_request = None
        return True
