import logging
from contextvars import ContextVar
from typing import Any, Dict, Optional
from opentelemetry.trace import get_current_span, format_trace_id, format_span_id

# Define context variables that can be set by framework-specific code
# (e.g., a Flask middleware or a Celery task signal).
request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)
user_var: ContextVar[Optional[Dict[str, Any]]] = ContextVar("user", default=None)


class RequestIDContextFilter(logging.Filter):
    """Injects a request_id from a context variable into the log record."""
    def filter(self, record):
        # Use the value from the context variable if 'request_id' is not already on the record.
        if not hasattr(record, "request_id"):
            record.request_id = request_id_var.get()
        return True

class UserContextFilter(logging.Filter):
    """Injects user information from a context variable into the log record."""
    def filter(self, record):
        # Use the value from the context variable if 'user' is not already on the record.
        if not hasattr(record, "user"):
            record.user = user_var.get()
        return True

class TraceContextFilter(logging.Filter):
    """Attach OTEL trace_id, span_id, span_name, and parent_span_id to log records."""
    def filter(self, record):
        span = get_current_span()
        ctx = span.get_span_context() if span else None
 
        record.trace_id = None
        record.span_id = None
        record.span_name = None
        record.parent_span_id = None
 
        if ctx and ctx.is_valid:
            record.trace_id = format_trace_id(ctx.trace_id)
            record.span_id = format_span_id(ctx.span_id)
            record.span_name = span.name
 
            # A span's parent is a SpanContext. We check if it's valid.
            if span.parent and span.parent.is_valid:
                record.parent_span_id = format_span_id(span.parent.span_id)
        return True
