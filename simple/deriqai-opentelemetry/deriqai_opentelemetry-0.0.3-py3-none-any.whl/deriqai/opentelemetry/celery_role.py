from enum import Enum, auto


class CeleryRole(Enum):
    WORKER = auto()
    PRODUCER = auto()