from .otel_core_formatter import OTELFormatter


class CeleryOTELFormatter(OTELFormatter):
    # The 'data' attribute is already reserved in the base OTELFormatter,
    # so no additional reservations are needed here.
    RESERVED_ATTRS = OTELFormatter.RESERVED_ATTRS | {"task_data"}

    def add_fields(self, log_record, record, message_dict):
        super().add_fields(log_record, record, message_dict)

        if hasattr(record, "task_data") and record.task_data is not None:
            log_record.setdefault("attributes", {})
            
            celery_request = {}
            task_id = record.task_data.get("id")
            if task_id:
                celery_request["task.id"] = task_id

            # These fields are typically present only on the initial "Executing task" log.
            for key in ["name", "args", "kwargs"]:
                value = record.task_data.get(key)
                if value:
                    celery_request[f"task.{key}"] = value
            log_record["attributes"]["celery_request"] = celery_request
