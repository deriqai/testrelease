import logging

def enable_celery_logger_propagation():
    celery_loggers = [
        "celery",
        "celery.task",
        "celery.worker",
        "celery.app",
        "celery.beat",
        "celery.redirected",
        "celery.pool",
    ]
    for logger_name in celery_loggers:
        logger = logging.getLogger(logger_name)
        logger.propagate = True

    # Suppress the default Celery task failure logger.
    # The OpenTelemetry instrumentor already captures task failures as exceptions
    # on the trace span, so Celery's default error log is redundant.
    # Setting propagate to False prevents these logs from reaching the root logger.
    # logging.getLogger("celery.app.trace").propagate = False
