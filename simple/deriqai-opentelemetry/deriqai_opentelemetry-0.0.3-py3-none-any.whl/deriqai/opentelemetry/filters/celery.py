import logging
from contextvars import ContextVar
from typing import Optional

# Context variable for the current task ID.
# This should be set by a Celery signal hook (e.g., task_prerun).
task_id_var: ContextVar[Optional[str]] = ContextVar("task_id", default=None)

class TaskContextFilter(logging.Filter):
    """Injects a task_id from a context variable into the log record."""
    def filter(self, record):
        # Use the value from the context variable if 'task_id' is not already on the record.
        if not hasattr(record, "task_id"):
            record.task_id = task_id_var.get()
        return True
