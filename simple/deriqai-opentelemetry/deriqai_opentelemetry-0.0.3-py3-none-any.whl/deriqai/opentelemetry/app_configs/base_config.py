import logging

# Flag to ensure handlers are only configured once on the root logger.
_handlers_configured = False

class BaseLoggingConfig:
    def __init__(self, resource=None, instrumentation_scope=None, filters=None, level=logging.INFO, handlers=None, formatter_class=None, **kwargs):
        # The **kwargs parameter makes the constructor more robust to extra arguments.
        self.resource = resource or {}
        self.instrumentation_scope = instrumentation_scope or {}
        self.filters = filters or []
        self.level = level
        self.handlers = handlers or [logging.StreamHandler()]
        self.formatter_class = formatter_class

    def get_filters(self):
        return self.filters

    def configure_handlers(self, root_logger=None):
        global _handlers_configured
        root_logger = root_logger or logging.getLogger()
        root_logger.setLevel(self.level)

        # The first call sets up the handlers. Subsequent calls will add their specific filters
        # to the already-existing handlers to avoid log duplication.
        if not _handlers_configured:
            for handler in self.handlers:
                handler.setFormatter(self.formatter_class(
                    resource=self.resource,
                    instrumentation_scope=self.instrumentation_scope
                ))
                for f in self.get_filters():
                    handler.addFilter(f)
                root_logger.addHandler(handler)
            _handlers_configured = True
        else:
            # Add any new filters from this configuration to the existing handlers.
            for handler in root_logger.handlers:
                for f in self.get_filters():
                    # Avoid adding duplicate filter instances by checking the filter's type.
                    if not any(isinstance(existing_f, type(f)) for existing_f in handler.filters):
                        handler.addFilter(f)

    def setup(self):
        self.configure_handlers()
