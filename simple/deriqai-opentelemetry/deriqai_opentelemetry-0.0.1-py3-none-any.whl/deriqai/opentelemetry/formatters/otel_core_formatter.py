from datetime import datetime, timezone
from pythonjsonlogger import jsonlogger

class OTELFormatter(jsonlogger.JsonFormatter):
    def __init__(self, resource=None, instrumentation_scope=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.resource = resource or {}
        self.instrumentation_scope = instrumentation_scope or {}

    def add_fields(self, log_record, record, message_dict):
        log_record.clear()
        log_record["timestamp"] = datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat().replace("+00:00", "Z")
        #datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        log_record["severity_text"] = getattr(record, "levelname", None)
        log_record["body"] = getattr(record, "message", "")

        attrs = {}
        # Add the logger name for better context within the application.
        attrs["logger.name"] = record.name

        for key in ["trace_id", "span_id", "span_name", "request_id", "user", "task_id"]:
            value = getattr(record, key, None)
            if value:
                attrs[key] = value

        if hasattr(record, "data"):
            if "exc" in record.data and record.exc_info:
                exc_type, exc_value, _ = record.exc_info
                attrs["events"] = [
                    {
                        "name": "exception",
                        "timestamp": record.created * 1e9,  # Convert to nanoseconds
                        "attributes": {
                            "exception.type": exc_type.__name__,
                            "exception.message": str(exc_value),
                            "exception.stacktrace": record.data.get("traceback", ""),
                        }
                    }
                ]
        if hasattr(record, "error") and record.error:
            attrs["error"] = record.error

        log_record["attributes"] = attrs
        log_record["resource"] = self.resource
        log_record["instrumentationScope"] = self.instrumentation_scope
