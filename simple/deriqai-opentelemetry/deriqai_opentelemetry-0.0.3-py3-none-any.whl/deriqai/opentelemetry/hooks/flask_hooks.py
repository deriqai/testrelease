import time

def attach_flask_hooks(app):
    pass