from datetime import datetime, timezone
from pythonjsonlogger import jsonlogger


class OTELFormatter(jsonlogger.JsonFormatter):
    # Define reserved attributes as a class variable set for efficient lookups.
    # Subclasses can extend this set with their own specific fields.
    RESERVED_ATTRS = {
        "args", "asctime", "created", "exc_info", "exc_text", "filename",
        "funcName", "levelname", "levelno", "lineno", "module",
        "msecs", "message", "msg", "name", "pathname", "process", "taskName",
        "processName", "relativeCreated", "stack_info", "thread", "threadName",
        "json_message", "json_fields",  # python-json-logger attributes
        # OTel-specific attributes that are handled separately in this class.
        "trace_id", "span_id", "parent_span_id", "span_name", "request_id", "user",
        "task_id", "data", "error",
    }

    def __init__(self, resource=None, instrumentation_scope=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.resource = resource or {}
        self.instrumentation_scope = instrumentation_scope or {}

    def add_fields(self, log_record, record, message_dict):
        log_record.clear()
        recorded_timestamp_iso = datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat().replace("+00:00", "Z")
        log_record["timestamp"] = recorded_timestamp_iso
        log_record["severity_text"] = getattr(record, "levelname", None)
        log_record["body"] = getattr(record, "message", "")

        attrs = {}
        # Add the logger name for better context within the application.
        attrs["logger.name"] = record.name

        for key in ["trace_id", "span_id", "parent_span_id", "span_name", "request_id", "user", "task_id"]:
            value = getattr(record, key, None)
            if value:
                attrs[key] = value

        if hasattr(record, "data"):
            if "exc" in record.data and record.exc_info:
                exc_type, exc_value, _ = record.exc_info
                attrs["events"] = [
                    {
                        "name": "exception",
                        "timestamp": recorded_timestamp_iso,  # Convert to nanoseconds
                        "attributes": {
                            "exception.type": exc_type.__name__,
                            "exception.message": str(exc_value),
                            "exception.stacktrace": record.data.get("traceback", ""),
                        }
                    }
                ]
        if hasattr(record, "error") and record.error:
            attrs["error"] = record.error

        # Add extra fields from the log record to attributes
        for key, value in record.__dict__.items():
            if key not in self.RESERVED_ATTRS and value is not None:
                attrs[key] = value

        log_record["attributes"] = attrs
        log_record["resource"] = self.resource
        log_record["instrumentationScope"] = self.instrumentation_scope
