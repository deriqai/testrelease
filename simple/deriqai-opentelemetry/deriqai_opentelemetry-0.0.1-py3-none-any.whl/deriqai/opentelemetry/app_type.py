from enum import Enum, auto


class AppType(Enum):
    FLASK = auto()
    CELERY = auto()
    OTEL_CORE = auto()