import logging
from opentelemetry import trace
from opentelemetry.sdk.trace import Span

def setup_celery_signals(celery_app):    

    def on_setup_logging(**kwargs):
        """Prevent Celery from configuring the default logging format."""
        pass

    def capture_producer_span(sender=None, body=None, headers=None, **kwargs):
        # At this point, the OpenTelemetry span is active
        span: Span = trace.get_current_span()
        span_id = format(span.get_span_context().span_id, "016x")
        trace_id = format(span.get_span_context().trace_id, "016x")
        parent_span_id = format(span.parent.span_id, "016x") if span.parent else "None"
        logger = logging.getLogger("deriqai.opentelemetry.celery.task.schedule")
        #: {span.name} ({span.kind.name}) | TraceID: {trace_id} SpanID: {span_id} | ParentID: {parent_span_id} 
        logger.info(f"Scheduled Celery task", extra={"Task": sender})      

    # By connecting a handler to the `setup_logging` signal, we prevent Celery
    # from setting up its own logging configuration, which would otherwise
    # override our OTEL-based setup. This function being present is enough to
    # signal to Celery that logging is handled externally.
    from celery.signals import setup_logging
    setup_logging.connect(on_setup_logging, weak=False)

    from celery.signals import after_task_publish
    after_task_publish.connect (capture_producer_span, weak=False)

    # Create a global TracedTask base class
    from celery import Task
    class TracedTask(Task):
        def __call__(self, *args, **kwargs):
            # At this point, the OpenTelemetry span is active
            span: Span = trace.get_current_span()
            span_id = format(span.get_span_context().span_id, "016x")
            trace_id = format(span.get_span_context().trace_id, "016x")
            parent_span_id = format(span.parent.span_id, "016x") if span.parent else "None"
            logger = logging.getLogger("deriqai.opentelemetry.celery.task.execute")
            logger.info(f"Executing Celery task")        
            return super().__call__(*args, **kwargs)


    # ----------------------------
    # Wrap the app.task decorator
    # ----------------------------
    _original_task_decorator = celery_app.task

    def traced_task_wrapper(*args, **kwargs):
        """
        Wraps celery_app.task to force all tasks to include TracedTask.
        """
        if "base" not in kwargs:
            kwargs["base"] = TracedTask
        else:
            # If app sets a custom base, create a hybrid class
            base_cls = kwargs["base"]
            class HybridTask(TracedTask, base_cls):
                pass
            kwargs["base"] = HybridTask
        return _original_task_decorator(*args, **kwargs)

    celery_app.task = traced_task_wrapper

    # ----------------------------
    # Optionally, patch already registered tasks
    # ----------------------------
    for name, task in celery_app.tasks.items():
        if not issubclass(task.__class__, TracedTask):
            # Create a hybrid task class dynamically
            class PatchedTask(TracedTask, task.__class__):
                pass
            task.__class__ = PatchedTask

def attach_celery_hooks(celery_app):
    setup_celery_signals(celery_app=celery_app)
    enable_celery_logger_propagation()

def enable_celery_logger_propagation():
    celery_loggers = [
        "celery",
        "celery.task",
        "celery.worker",
        "celery.app",
        "celery.beat",
        "celery.redirected",
        "celery.pool",
    ]
    for logger_name in celery_loggers:
        logger = logging.getLogger(logger_name)
        logger.propagate = True

    # Suppress the default Celery task failure logger.
    # The OpenTelemetry instrumentor already captures task failures as exceptions
    # on the trace span, so Celery's default error log is redundant.
    # Setting propagate to False prevents these logs from reaching the root logger.
    # logging.getLogger("celery.app.trace").propagate = False

