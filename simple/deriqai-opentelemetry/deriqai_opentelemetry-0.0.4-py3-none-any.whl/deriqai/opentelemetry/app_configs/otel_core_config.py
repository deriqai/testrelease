from .base_config import BaseLoggingConfig
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource

# Flag to ensure the SDK is only initialized once per process.
_otel_sdk_initialized = False

class OtelCoreLoggingConfig(BaseLoggingConfig):
    def setup(self):
        """
        Configures the base logging and initializes the OpenTelemetry SDK.
        This setup is designed to be idempotent.
        """
        super().setup()

        global _otel_sdk_initialized
        if _otel_sdk_initialized:
            return

        resource = Resource.create(self.resource)
        provider = TracerProvider(resource=resource)

        trace.set_tracer_provider(provider)
        _otel_sdk_initialized = True
