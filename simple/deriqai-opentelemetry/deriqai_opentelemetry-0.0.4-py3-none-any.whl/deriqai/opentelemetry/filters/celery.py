import logging
from contextvars import ContextVar
from typing import Any, Dict, Optional

# Context variables to hold task information during execution.
# These are populated by signal handlers in `hooks/celery_hooks.py`.
task_id_var: ContextVar[Optional[str]] = ContextVar("task_id", default=None)
task_data_var: ContextVar[Optional[Dict[str, Any]]] = ContextVar("task_data", default=None)

class TaskContextFilter(logging.Filter):
    """
    Injects Celery task context (`task_id` and `celery_request`) into the log record.
    This filter relies on Celery signals (connected in celery_hooks) to
    populate the context variables.
    """
    def filter(self, record):
        if not hasattr(record, "task_id"):
            record.task_id = task_id_var.get()
        # The CeleryOTELFormatter looks for the 'task_data' attribute to add the 'celery_request' block.
        if not hasattr(record, "task_data"):
            record.task_data = task_data_var.get()
        return True
