from .otel_core_formatter import OTELFormatter


class CeleryOTELFormatter(OTELFormatter):
    def add_fields(self, log_record, record, message_dict):
        super().add_fields(log_record, record, message_dict)

        if hasattr(record, "data"):
            log_record.setdefault("attributes", {})
            log_record["attributes"]["celery_request"] = {
                "task_id": record.data.get("id", ""),
                "task_name": record.data.get("name", ""),
                "task_args": record.data.get("args", ""),
                "task_kwargs": record.data.get("kwargs", ""),
            }

