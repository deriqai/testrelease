from .otel_core_formatter import OTELFormatter

class FlaskOTELFormatter(OTELFormatter):
    def add_fields(self, log_record, record, message_dict):
        # First, run the parent's add_fields to get the base attributes
        super().add_fields(log_record, record, message_dict)

        # Now, add Flask-specific attributes if they exist
        if hasattr(record, "flask_request") and record.flask_request:
            log_record.setdefault("attributes", {})
            log_record["attributes"]["flask_request"] = record.flask_request
