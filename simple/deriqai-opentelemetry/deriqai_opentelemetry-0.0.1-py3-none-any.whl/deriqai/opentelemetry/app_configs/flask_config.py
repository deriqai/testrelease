from .otel_core_config import OtelCoreLoggingConfig
from ..hooks.flask_hooks import attach_flask_hooks
from ..filters.flask import FlaskRequestContextFilter
from ..formatters.flask_formatter import FlaskOTELFormatter

class FlaskLoggingConfig(OtelCoreLoggingConfig):
    def __init__(self, flask_app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.flask_app = flask_app
        self.filters.append(FlaskRequestContextFilter())
        self.formatter_class = FlaskOTELFormatter

    def setup(self):
        super().setup()
        from opentelemetry.instrumentation.flask import FlaskInstrumentor
        FlaskInstrumentor().instrument_app(self.flask_app)
        attach_flask_hooks(self.flask_app)
